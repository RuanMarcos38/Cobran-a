# Assessoria de Cobrança com Agente de IA + N8N

Pacote profissional para implantação de um fluxo de atendimento e cobrança multicanal com WhatsApp, e-mail, tarefa de ligação, banco de dados, trilha de auditoria, pausa/digitando e escalonamento humano.

## O que foi entregue

- `workflows/assessoria-cobranca-n8n.json` — workflow pronto para importar no N8N.
- `database/supabase-schema.sql` — estrutura completa de banco PostgreSQL/Supabase.
- `templates/mensagens-cobranca.json` — modelos humanizados por etapa de cobrança.
- `docs/fluxo-operacional-cobranca.md` — mapa completo do processo de cobrança.
- `.env.example` — variáveis de ambiente para configurar N8N, Supabase, WhatsApp, e-mail, voz e IA.

## Visão geral do fluxo

O fluxo faz atendimento receptivo e cobrança ativa:

1. Recebe eventos do WhatsApp via webhook.
2. Normaliza telefone, nome, mensagem, canal e payload.
3. Consulta devedor, dívida, status de contestação, acordo, pagamento e bloqueios.
4. Executa motor de decisão com regras de cobrança, LGPD/CDC, horário permitido, limite de tentativas e intenção do cliente.
5. Gera resposta com IA, mantendo linguagem humana, respeitosa, curta e consultiva.
6. Envia presença de “digitando” no WhatsApp antes da resposta.
7. Envia WhatsApp, e-mail e cria tarefa/ligação conforme estágio da dívida.
8. Registra tudo em banco: mensagem, status, canal, tentativa, motivo, etapa, auditoria e próximo passo.
9. Escala para humano em casos de contestação, comprovante, pagamento informado, negociação sensível, reclamação, LGPD, advogado ou risco de constrangimento.

## Regras importantes de compliance

Este pacote evita ameaça, exposição, linguagem abusiva, cobrança fora do horário configurado, insistência excessiva e cobrança quando o cliente informa pagamento/contestação. O operador deve revisar as políticas internas e adequar horários, templates, consentimentos, base legal, contratos e provedores antes de ativar produção.

## Como importar no N8N

1. Abra o N8N.
2. Vá em **Workflows > Import from file**.
3. Importe `workflows/assessoria-cobranca-n8n.json`.
4. Configure as variáveis de ambiente do `.env.example`.
5. Execute o SQL de `database/supabase-schema.sql` no Supabase.
6. Configure as credenciais dos provedores:
   - Evolution API ou outro provedor WhatsApp.
   - Supabase REST.
   - OpenAI API.
   - Provedor de e-mail transacional.
   - Provedor de voz/telefonia, se for usar ligação automática ou tarefa de ligação.
7. Ative o workflow.

## Webhooks previstos

- WhatsApp inbound: `/webhook/cobranca-whatsapp-in`
- Disparos ativos: executados a cada 15 minutos pelo Schedule Trigger.

## Observação operacional

O workflow está pronto para importar, mas precisa das chaves reais dos provedores. Nenhum fluxo de cobrança deve ser ativado sem revisão jurídica, política de privacidade, DPA/contrato com clientes e validação dos templates por um responsável da operação.
